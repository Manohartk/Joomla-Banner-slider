<?php
/**
 * @package		SMART
 * @subpackage	mod_smart_banner_slider
 * @copyright	Copyright (C) 2016 smart.com - All rights reserved.
 */
//no direct access
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
// Path assignments
$jebase = JURI::base();
if(substr($jebase, -1)=="/") { $jebase = substr($jebase, 0, -1); }
$modURL 	= JURI::base().'modules/mod_smart_banner_slider';
// get parameters from the module's configuration
// $jQuery = $params->get("jQuery");

//Add your Banner animation here

$Animation = $params->get('Animation','slide');
$Easing = $params->get('Easing','swing');
$Direction = $params->get('Direction','horizontal');
$Reverse = $params->get('Reverse','false');
$AnimationLoop = $params->get('AnimationLoop','true');
$SmoothHeight = $params->get('SmoothHeight','false');
$StartAt = $params->get('StartAt','0');
$SlideShow = $params->get('SlideShow','true');
$SlideShowSpeed = $params->get('SlideShowSpeed','7000');
$AnimationSpeed = $params->get('AnimationSpeed','600');
$InitDelay = $params->get('InitDelay','0');
$Randomize = $params->get('Randomize','false');
$PauseOnAction = $params->get('PauseOnAction','true');
$PauseOnHover = $params->get('PauseOnHover','false');
$UseCss = $params->get('UseCss','true');
$Touch = $params->get('Touch','true');

$slideNumbers = $params->get('slideNumbers','true');
$navigation = $params->get('navigation','true');
$bullets = $params->get('bullets','true');
// $linkTarget = $params->get('linkTarget','_self');
$linkTarget = '_self'; // $params->get('linkTarget','_self');

$Image[]= $params->get( '!', "" );
$Title[]= $params->get( '!', "" );
$Caption[]= $params->get( '!', "" );
$Link[]= $params->get( '!', "" );
$Irg[]= $params->get( '!', "" );

//Banner images list displayed here

for ($j=1; $j<=20; $j++)
{
	$Image[] = $params->get( 'Image'.$j , "" );
	$Title[] = $params->get( 'Title'.$j , "" );
	$Caption[] = $params->get( 'Caption'.$j , "" );
	$Link[]	= $params->get( 'Link'.$j , "" );	
	$Irg[]	= $params->get( 'Irg'.$j , "" );	
}

$app = JFactory::getApplication();
$template = $app->getTemplate();
$doc = JFactory::getDocument(); //only include if not already included
$doc->addStyleSheet( $modURL . '/css/flexslider.css');
$doc->addStyleSheet( $modURL . '/css/smart_banner_slider.css');
if ($params->get('jQuery')) {$doc->addScript ('http://code.jquery.com/jquery-latest.pack.js');}
$doc->addScript($modURL . '/js/jquery.flexslider-min.js');
$doc = JFactory::getDocument();
$js = '';
$doc->addScriptDeclaration($js);
?>

<!--Start Banner images and bottom text  displyed postion -->
<div id="slider" class="flexslider smart-images">
    <ul class="slides ">
      <?php
      for ($i=0; $i<=20; $i++){
          if ($Image[$i] != null) { ?>
          
          <li>
          <?php echo '<img src="'.$Image[$i].'"/>';
              if ($Caption[$i] != null) {
                echo '<div class="smart-banner-caption"><h3>'.$Title[$i].'</h3>
                    <p>'.$Caption[$i].'</p>
                    <a href="'.$Link[$i].'" class="pull-right text-lg square-box">
                      <img alt="read more" src="modules/mod_smart_banner_slider/images/black-more-icon.png" />
                    </a>
                  </div>'; 
              } 
              else {
                echo '<div id="nocaption" class="smart_banner_slider-caption"></div>';
              }?>
          
          </li>
      <?php }};  ?>    
    </ul>
</div>
<!--End  Banner images and bottom text  displyed postion -->

<!--Start  Banner Caption text are displyed here -->
<div class="flexslider smart-images smart-caption-up" id="carousel">
  <ul class="slides smart-caption-text">
    <?php
    for ($i=1; $i<=20; $i++){
        if ($Image[$i] != null) { ?>  
          <li class="smart-thumbnail-caption left-catption-smart">
            <?php echo $Irg[$i]; ?>
          </li>
    <?php }
    } ?>
  </ul>
</div> 
<!--End Banner Caption text are displyed here -->


<script>
//$(window).load(function() {
// $(document).ready(function(){
$(function() {	


  $('#carousel').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: false,
    slideshow: false,
    itemWidth: 210,
    itemMargin: 5,
	minItems: 6,
	maxItems: 6,
	asNavFor: '#slider'

  }); 
  $('#slider').flexslider({
	  
      animation: '<?php echo $Animation; ?>', 
      easing: '<?php echo $Easing; ?>', 
      direction: '<?php echo $Direction; ?>', 
      reverse: <?php echo $Reverse; ?>, 
      animationLoop: <?php echo $AnimationLoop; ?>, 
      smoothHeight: <?php echo $SmoothHeight; ?>, 
      startAt: <?php echo $StartAt; ?>, 
      slideShow: <?php echo $SlideShow; ?>, 
      slideShowSpeed: <?php echo $SlideShowSpeed; ?>, 
      animationSpeed: <?php echo $AnimationSpeed; ?>, 
      initDelay: <?php echo $InitDelay; ?>, 
      pauseOnAction: <?php echo $PauseOnAction; ?>, 
      pauseOnHover: <?php echo $PauseOnHover; ?>, 
      useCSS: <?php echo $UseCss; ?>, 
      touch: <?php echo $Touch; ?>,
	  sync: '#carousel'


	  /*
	   before: function(slider) {
		var slideno = slider.currentSlide;
		  $('.smart-caption-text').find('.flex-active-slide').removeClass('flex-active-slide');
		  $('.smart-caption-text').children('li').eq(slideno).addClass('flex-active-slide');
		} 	     */
		
  });  
  
  
  $('.flex-next,.flex-prev').html('');
});



</script>
